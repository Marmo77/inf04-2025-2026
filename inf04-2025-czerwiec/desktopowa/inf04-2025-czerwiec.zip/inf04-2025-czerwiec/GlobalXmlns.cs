[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "inf04_2025_czerwiec")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "inf04_2025_czerwiec.Pages")]
